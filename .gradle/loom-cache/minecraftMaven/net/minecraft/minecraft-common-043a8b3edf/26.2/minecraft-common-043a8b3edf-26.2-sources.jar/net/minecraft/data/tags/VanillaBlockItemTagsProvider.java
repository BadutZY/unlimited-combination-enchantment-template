package net.minecraft.data.tags;

import java.util.function.Function;
import net.minecraft.references.BlockItemId;
import net.minecraft.references.BlockItemIds;
import net.minecraft.tags.BlockItemTagId;
import net.minecraft.tags.BlockItemTags;

public class VanillaBlockItemTagsProvider extends BlockItemTagsProvider {
	protected VanillaBlockItemTagsProvider(final Function<BlockItemTagId, BlockItemTagsProvider.CombinedAppender> tagSupplier) {
		super(tagSupplier);
	}

	@Override
	protected void run() {
		BlockItemId[] smallFlowersInteractingWithBees = new BlockItemId[]{
			BlockItemIds.DANDELION,
			BlockItemIds.OPEN_EYEBLOSSOM,
			BlockItemIds.POPPY,
			BlockItemIds.BLUE_ORCHID,
			BlockItemIds.ALLIUM,
			BlockItemIds.AZURE_BLUET,
			BlockItemIds.RED_TULIP,
			BlockItemIds.ORANGE_TULIP,
			BlockItemIds.WHITE_TULIP,
			BlockItemIds.PINK_TULIP,
			BlockItemIds.OXEYE_DAISY,
			BlockItemIds.CORNFLOWER,
			BlockItemIds.LILY_OF_THE_VALLEY,
			BlockItemIds.WITHER_ROSE,
			BlockItemIds.TORCHFLOWER
		};
		BlockItemId[] otherFlowers = new BlockItemId[]{
			BlockItemIds.SUNFLOWER,
			BlockItemIds.LILAC,
			BlockItemIds.PEONY,
			BlockItemIds.ROSE_BUSH,
			BlockItemIds.PITCHER_PLANT,
			BlockItemIds.FLOWERING_AZALEA_LEAVES,
			BlockItemIds.FLOWERING_AZALEA,
			BlockItemIds.MANGROVE_PROPAGULE,
			BlockItemIds.CHERRY_LEAVES,
			BlockItemIds.PINK_PETALS,
			BlockItemIds.WILDFLOWERS,
			BlockItemIds.CHORUS_FLOWER,
			BlockItemIds.SPORE_BLOSSOM,
			BlockItemIds.CACTUS_FLOWER
		};
		this.tag(BlockItemTags.WOOL).addAll(BlockItemIds.WOOL.asList());
		this.tag(BlockItemTags.PLANKS)
			.add(
				BlockItemIds.OAK_PLANKS,
				BlockItemIds.SPRUCE_PLANKS,
				BlockItemIds.BIRCH_PLANKS,
				BlockItemIds.JUNGLE_PLANKS,
				BlockItemIds.ACACIA_PLANKS,
				BlockItemIds.DARK_OAK_PLANKS,
				BlockItemIds.PALE_OAK_PLANKS,
				BlockItemIds.CRIMSON_PLANKS,
				BlockItemIds.WARPED_PLANKS,
				BlockItemIds.MANGROVE_PLANKS,
				BlockItemIds.BAMBOO_PLANKS,
				BlockItemIds.CHERRY_PLANKS
			);
		this.tag(BlockItemTags.STONE_BRICKS)
			.add(BlockItemIds.STONE_BRICKS, BlockItemIds.MOSSY_STONE_BRICKS, BlockItemIds.CRACKED_STONE_BRICKS, BlockItemIds.CHISELED_STONE_BRICKS);
		this.tag(BlockItemTags.WOODEN_BUTTONS)
			.add(
				BlockItemIds.OAK_BUTTON,
				BlockItemIds.SPRUCE_BUTTON,
				BlockItemIds.BIRCH_BUTTON,
				BlockItemIds.JUNGLE_BUTTON,
				BlockItemIds.ACACIA_BUTTON,
				BlockItemIds.DARK_OAK_BUTTON,
				BlockItemIds.PALE_OAK_BUTTON,
				BlockItemIds.CRIMSON_BUTTON,
				BlockItemIds.WARPED_BUTTON,
				BlockItemIds.MANGROVE_BUTTON,
				BlockItemIds.BAMBOO_BUTTON,
				BlockItemIds.CHERRY_BUTTON
			);
		this.tag(BlockItemTags.STONE_BUTTONS).add(BlockItemIds.STONE_BUTTON, BlockItemIds.POLISHED_BLACKSTONE_BUTTON);
		this.tag(BlockItemTags.BUTTONS).addTag(BlockItemTags.WOODEN_BUTTONS).addTag(BlockItemTags.STONE_BUTTONS);
		this.tag(BlockItemTags.WOOL_CARPETS).addAll(BlockItemIds.CARPET.asList());
		this.tag(BlockItemTags.WOODEN_DOORS)
			.add(
				BlockItemIds.OAK_DOOR,
				BlockItemIds.SPRUCE_DOOR,
				BlockItemIds.BIRCH_DOOR,
				BlockItemIds.JUNGLE_DOOR,
				BlockItemIds.ACACIA_DOOR,
				BlockItemIds.DARK_OAK_DOOR,
				BlockItemIds.PALE_OAK_DOOR,
				BlockItemIds.CRIMSON_DOOR,
				BlockItemIds.WARPED_DOOR,
				BlockItemIds.MANGROVE_DOOR,
				BlockItemIds.BAMBOO_DOOR,
				BlockItemIds.CHERRY_DOOR
			);
		this.tag(BlockItemTags.WOODEN_STAIRS)
			.add(
				BlockItemIds.OAK_STAIRS,
				BlockItemIds.SPRUCE_STAIRS,
				BlockItemIds.BIRCH_STAIRS,
				BlockItemIds.JUNGLE_STAIRS,
				BlockItemIds.ACACIA_STAIRS,
				BlockItemIds.DARK_OAK_STAIRS,
				BlockItemIds.PALE_OAK_STAIRS,
				BlockItemIds.CRIMSON_STAIRS,
				BlockItemIds.WARPED_STAIRS,
				BlockItemIds.MANGROVE_STAIRS,
				BlockItemIds.BAMBOO_STAIRS,
				BlockItemIds.CHERRY_STAIRS
			);
		this.tag(BlockItemTags.WOODEN_SLABS)
			.add(
				BlockItemIds.OAK_SLAB,
				BlockItemIds.SPRUCE_SLAB,
				BlockItemIds.BIRCH_SLAB,
				BlockItemIds.JUNGLE_SLAB,
				BlockItemIds.ACACIA_SLAB,
				BlockItemIds.DARK_OAK_SLAB,
				BlockItemIds.PALE_OAK_SLAB,
				BlockItemIds.CRIMSON_SLAB,
				BlockItemIds.WARPED_SLAB,
				BlockItemIds.MANGROVE_SLAB,
				BlockItemIds.BAMBOO_SLAB,
				BlockItemIds.CHERRY_SLAB
			);
		this.tag(BlockItemTags.WOODEN_FENCES)
			.add(
				BlockItemIds.OAK_FENCE,
				BlockItemIds.ACACIA_FENCE,
				BlockItemIds.DARK_OAK_FENCE,
				BlockItemIds.PALE_OAK_FENCE,
				BlockItemIds.SPRUCE_FENCE,
				BlockItemIds.BIRCH_FENCE,
				BlockItemIds.JUNGLE_FENCE,
				BlockItemIds.CRIMSON_FENCE,
				BlockItemIds.WARPED_FENCE,
				BlockItemIds.MANGROVE_FENCE,
				BlockItemIds.BAMBOO_FENCE,
				BlockItemIds.CHERRY_FENCE
			);
		this.tag(BlockItemTags.FENCE_GATES)
			.add(
				BlockItemIds.ACACIA_FENCE_GATE,
				BlockItemIds.BIRCH_FENCE_GATE,
				BlockItemIds.DARK_OAK_FENCE_GATE,
				BlockItemIds.PALE_OAK_FENCE_GATE,
				BlockItemIds.JUNGLE_FENCE_GATE,
				BlockItemIds.OAK_FENCE_GATE,
				BlockItemIds.SPRUCE_FENCE_GATE,
				BlockItemIds.CRIMSON_FENCE_GATE,
				BlockItemIds.WARPED_FENCE_GATE,
				BlockItemIds.MANGROVE_FENCE_GATE,
				BlockItemIds.BAMBOO_FENCE_GATE,
				BlockItemIds.CHERRY_FENCE_GATE
			);
		this.tag(BlockItemTags.WOODEN_PRESSURE_PLATES)
			.add(
				BlockItemIds.OAK_PRESSURE_PLATE,
				BlockItemIds.SPRUCE_PRESSURE_PLATE,
				BlockItemIds.BIRCH_PRESSURE_PLATE,
				BlockItemIds.JUNGLE_PRESSURE_PLATE,
				BlockItemIds.ACACIA_PRESSURE_PLATE,
				BlockItemIds.DARK_OAK_PRESSURE_PLATE,
				BlockItemIds.PALE_OAK_PRESSURE_PLATE,
				BlockItemIds.CRIMSON_PRESSURE_PLATE,
				BlockItemIds.WARPED_PRESSURE_PLATE,
				BlockItemIds.MANGROVE_PRESSURE_PLATE,
				BlockItemIds.BAMBOO_PRESSURE_PLATE,
				BlockItemIds.CHERRY_PRESSURE_PLATE
			);
		this.tag(BlockItemTags.DOORS).addTag(BlockItemTags.WOODEN_DOORS).addAll(BlockItemIds.COPPER_DOOR.asList()).add(BlockItemIds.IRON_DOOR);
		this.tag(BlockItemTags.SAPLINGS)
			.add(
				BlockItemIds.OAK_SAPLING,
				BlockItemIds.SPRUCE_SAPLING,
				BlockItemIds.BIRCH_SAPLING,
				BlockItemIds.JUNGLE_SAPLING,
				BlockItemIds.ACACIA_SAPLING,
				BlockItemIds.DARK_OAK_SAPLING,
				BlockItemIds.PALE_OAK_SAPLING,
				BlockItemIds.AZALEA,
				BlockItemIds.FLOWERING_AZALEA,
				BlockItemIds.MANGROVE_PROPAGULE,
				BlockItemIds.CHERRY_SAPLING
			);
		this.tag(BlockItemTags.BAMBOO_BLOCKS).add(BlockItemIds.BAMBOO_BLOCK, BlockItemIds.STRIPPED_BAMBOO_BLOCK);
		this.tag(BlockItemTags.OAK_LOGS).add(BlockItemIds.OAK_LOG, BlockItemIds.OAK_WOOD, BlockItemIds.STRIPPED_OAK_LOG, BlockItemIds.STRIPPED_OAK_WOOD);
		this.tag(BlockItemTags.DARK_OAK_LOGS)
			.add(BlockItemIds.DARK_OAK_LOG, BlockItemIds.DARK_OAK_WOOD, BlockItemIds.STRIPPED_DARK_OAK_LOG, BlockItemIds.STRIPPED_DARK_OAK_WOOD);
		this.tag(BlockItemTags.PALE_OAK_LOGS)
			.add(BlockItemIds.PALE_OAK_LOG, BlockItemIds.PALE_OAK_WOOD, BlockItemIds.STRIPPED_PALE_OAK_LOG, BlockItemIds.STRIPPED_PALE_OAK_WOOD);
		this.tag(BlockItemTags.BIRCH_LOGS).add(BlockItemIds.BIRCH_LOG, BlockItemIds.BIRCH_WOOD, BlockItemIds.STRIPPED_BIRCH_LOG, BlockItemIds.STRIPPED_BIRCH_WOOD);
		this.tag(BlockItemTags.ACACIA_LOGS)
			.add(BlockItemIds.ACACIA_LOG, BlockItemIds.ACACIA_WOOD, BlockItemIds.STRIPPED_ACACIA_LOG, BlockItemIds.STRIPPED_ACACIA_WOOD);
		this.tag(BlockItemTags.SPRUCE_LOGS)
			.add(BlockItemIds.SPRUCE_LOG, BlockItemIds.SPRUCE_WOOD, BlockItemIds.STRIPPED_SPRUCE_LOG, BlockItemIds.STRIPPED_SPRUCE_WOOD);
		this.tag(BlockItemTags.MANGROVE_LOGS)
			.add(BlockItemIds.MANGROVE_LOG, BlockItemIds.MANGROVE_WOOD, BlockItemIds.STRIPPED_MANGROVE_LOG, BlockItemIds.STRIPPED_MANGROVE_WOOD);
		this.tag(BlockItemTags.JUNGLE_LOGS)
			.add(BlockItemIds.JUNGLE_LOG, BlockItemIds.JUNGLE_WOOD, BlockItemIds.STRIPPED_JUNGLE_LOG, BlockItemIds.STRIPPED_JUNGLE_WOOD);
		this.tag(BlockItemTags.CHERRY_LOGS)
			.add(BlockItemIds.CHERRY_LOG, BlockItemIds.CHERRY_WOOD, BlockItemIds.STRIPPED_CHERRY_LOG, BlockItemIds.STRIPPED_CHERRY_WOOD);
		this.tag(BlockItemTags.CRIMSON_STEMS)
			.add(BlockItemIds.CRIMSON_STEM, BlockItemIds.STRIPPED_CRIMSON_STEM, BlockItemIds.CRIMSON_HYPHAE, BlockItemIds.STRIPPED_CRIMSON_HYPHAE);
		this.tag(BlockItemTags.WARPED_STEMS)
			.add(BlockItemIds.WARPED_STEM, BlockItemIds.STRIPPED_WARPED_STEM, BlockItemIds.WARPED_HYPHAE, BlockItemIds.STRIPPED_WARPED_HYPHAE);
		this.tag(BlockItemTags.WART_BLOCKS).add(BlockItemIds.NETHER_WART_BLOCK, BlockItemIds.WARPED_WART_BLOCK);
		this.tag(BlockItemTags.LOGS_THAT_BURN)
			.addTag(BlockItemTags.DARK_OAK_LOGS)
			.addTag(BlockItemTags.PALE_OAK_LOGS)
			.addTag(BlockItemTags.OAK_LOGS)
			.addTag(BlockItemTags.ACACIA_LOGS)
			.addTag(BlockItemTags.BIRCH_LOGS)
			.addTag(BlockItemTags.JUNGLE_LOGS)
			.addTag(BlockItemTags.SPRUCE_LOGS)
			.addTag(BlockItemTags.MANGROVE_LOGS)
			.addTag(BlockItemTags.CHERRY_LOGS);
		this.tag(BlockItemTags.LOGS).addTag(BlockItemTags.LOGS_THAT_BURN).addTag(BlockItemTags.CRIMSON_STEMS).addTag(BlockItemTags.WARPED_STEMS);
		this.tag(BlockItemTags.SAND).add(BlockItemIds.SAND, BlockItemIds.RED_SAND, BlockItemIds.SUSPICIOUS_SAND);
		this.tag(BlockItemTags.SMELTS_TO_GLASS).add(BlockItemIds.SAND, BlockItemIds.RED_SAND);
		this.tag(BlockItemTags.SLABS)
			.addTag(BlockItemTags.WOODEN_SLABS)
			.add(BlockItemIds.BAMBOO_MOSAIC_SLAB)
			.add(
				BlockItemIds.STONE_SLAB,
				BlockItemIds.SMOOTH_STONE_SLAB,
				BlockItemIds.STONE_BRICK_SLAB,
				BlockItemIds.SANDSTONE_SLAB,
				BlockItemIds.PURPUR_SLAB,
				BlockItemIds.QUARTZ_SLAB,
				BlockItemIds.RED_SANDSTONE_SLAB,
				BlockItemIds.BRICK_SLAB,
				BlockItemIds.COBBLESTONE_SLAB,
				BlockItemIds.NETHER_BRICK_SLAB,
				BlockItemIds.PETRIFIED_OAK_SLAB,
				BlockItemIds.PRISMARINE_SLAB,
				BlockItemIds.PRISMARINE_BRICK_SLAB,
				BlockItemIds.DARK_PRISMARINE_SLAB,
				BlockItemIds.POLISHED_GRANITE_SLAB,
				BlockItemIds.SMOOTH_RED_SANDSTONE_SLAB,
				BlockItemIds.MOSSY_STONE_BRICK_SLAB,
				BlockItemIds.POLISHED_DIORITE_SLAB,
				BlockItemIds.MOSSY_COBBLESTONE_SLAB,
				BlockItemIds.END_STONE_BRICK_SLAB,
				BlockItemIds.SMOOTH_SANDSTONE_SLAB,
				BlockItemIds.SMOOTH_QUARTZ_SLAB,
				BlockItemIds.GRANITE_SLAB,
				BlockItemIds.ANDESITE_SLAB,
				BlockItemIds.RED_NETHER_BRICK_SLAB,
				BlockItemIds.POLISHED_ANDESITE_SLAB,
				BlockItemIds.DIORITE_SLAB,
				BlockItemIds.CUT_SANDSTONE_SLAB,
				BlockItemIds.CUT_RED_SANDSTONE_SLAB,
				BlockItemIds.BLACKSTONE_SLAB,
				BlockItemIds.POLISHED_BLACKSTONE_BRICK_SLAB,
				BlockItemIds.POLISHED_BLACKSTONE_SLAB,
				BlockItemIds.COBBLED_DEEPSLATE_SLAB,
				BlockItemIds.POLISHED_DEEPSLATE_SLAB,
				BlockItemIds.DEEPSLATE_TILE_SLAB,
				BlockItemIds.DEEPSLATE_BRICK_SLAB,
				BlockItemIds.MUD_BRICK_SLAB,
				BlockItemIds.TUFF_SLAB,
				BlockItemIds.POLISHED_TUFF_SLAB,
				BlockItemIds.TUFF_BRICK_SLAB,
				BlockItemIds.RESIN_BRICK_SLAB,
				BlockItemIds.CINNABAR_SLAB,
				BlockItemIds.POLISHED_CINNABAR_SLAB,
				BlockItemIds.CINNABAR_BRICK_SLAB,
				BlockItemIds.SULFUR_SLAB,
				BlockItemIds.POLISHED_SULFUR_SLAB,
				BlockItemIds.SULFUR_BRICK_SLAB
			)
			.addAll(BlockItemIds.CUT_COPPER_SLAB.asList());
		this.tag(BlockItemTags.WALLS)
			.add(
				BlockItemIds.COBBLESTONE_WALL,
				BlockItemIds.MOSSY_COBBLESTONE_WALL,
				BlockItemIds.BRICK_WALL,
				BlockItemIds.PRISMARINE_WALL,
				BlockItemIds.RED_SANDSTONE_WALL,
				BlockItemIds.MOSSY_STONE_BRICK_WALL,
				BlockItemIds.GRANITE_WALL,
				BlockItemIds.STONE_BRICK_WALL,
				BlockItemIds.NETHER_BRICK_WALL,
				BlockItemIds.ANDESITE_WALL,
				BlockItemIds.RED_NETHER_BRICK_WALL,
				BlockItemIds.SANDSTONE_WALL,
				BlockItemIds.END_STONE_BRICK_WALL,
				BlockItemIds.DIORITE_WALL,
				BlockItemIds.BLACKSTONE_WALL,
				BlockItemIds.POLISHED_BLACKSTONE_BRICK_WALL,
				BlockItemIds.POLISHED_BLACKSTONE_WALL,
				BlockItemIds.COBBLED_DEEPSLATE_WALL,
				BlockItemIds.POLISHED_DEEPSLATE_WALL,
				BlockItemIds.DEEPSLATE_TILE_WALL,
				BlockItemIds.DEEPSLATE_BRICK_WALL,
				BlockItemIds.MUD_BRICK_WALL,
				BlockItemIds.TUFF_WALL,
				BlockItemIds.POLISHED_TUFF_WALL,
				BlockItemIds.TUFF_BRICK_WALL,
				BlockItemIds.RESIN_BRICK_WALL,
				BlockItemIds.CINNABAR_WALL,
				BlockItemIds.POLISHED_CINNABAR_WALL,
				BlockItemIds.CINNABAR_BRICK_WALL,
				BlockItemIds.SULFUR_WALL,
				BlockItemIds.POLISHED_SULFUR_WALL,
				BlockItemIds.SULFUR_BRICK_WALL
			);
		this.tag(BlockItemTags.STAIRS)
			.addTag(BlockItemTags.WOODEN_STAIRS)
			.add(BlockItemIds.BAMBOO_MOSAIC_STAIRS)
			.add(
				BlockItemIds.COBBLESTONE_STAIRS,
				BlockItemIds.SANDSTONE_STAIRS,
				BlockItemIds.NETHER_BRICK_STAIRS,
				BlockItemIds.STONE_BRICK_STAIRS,
				BlockItemIds.BRICK_STAIRS,
				BlockItemIds.PURPUR_STAIRS,
				BlockItemIds.QUARTZ_STAIRS,
				BlockItemIds.RED_SANDSTONE_STAIRS,
				BlockItemIds.PRISMARINE_BRICK_STAIRS,
				BlockItemIds.PRISMARINE_STAIRS,
				BlockItemIds.DARK_PRISMARINE_STAIRS,
				BlockItemIds.POLISHED_GRANITE_STAIRS,
				BlockItemIds.SMOOTH_RED_SANDSTONE_STAIRS,
				BlockItemIds.MOSSY_STONE_BRICK_STAIRS,
				BlockItemIds.POLISHED_DIORITE_STAIRS,
				BlockItemIds.MOSSY_COBBLESTONE_STAIRS,
				BlockItemIds.END_STONE_BRICK_STAIRS,
				BlockItemIds.STONE_STAIRS,
				BlockItemIds.SMOOTH_SANDSTONE_STAIRS,
				BlockItemIds.SMOOTH_QUARTZ_STAIRS,
				BlockItemIds.GRANITE_STAIRS,
				BlockItemIds.ANDESITE_STAIRS,
				BlockItemIds.RED_NETHER_BRICK_STAIRS,
				BlockItemIds.POLISHED_ANDESITE_STAIRS,
				BlockItemIds.DIORITE_STAIRS,
				BlockItemIds.BLACKSTONE_STAIRS,
				BlockItemIds.POLISHED_BLACKSTONE_BRICK_STAIRS,
				BlockItemIds.POLISHED_BLACKSTONE_STAIRS,
				BlockItemIds.COBBLED_DEEPSLATE_STAIRS,
				BlockItemIds.POLISHED_DEEPSLATE_STAIRS,
				BlockItemIds.DEEPSLATE_TILE_STAIRS,
				BlockItemIds.DEEPSLATE_BRICK_STAIRS,
				BlockItemIds.MUD_BRICK_STAIRS,
				BlockItemIds.TUFF_STAIRS,
				BlockItemIds.POLISHED_TUFF_STAIRS,
				BlockItemIds.TUFF_BRICK_STAIRS,
				BlockItemIds.RESIN_BRICK_STAIRS,
				BlockItemIds.CINNABAR_STAIRS,
				BlockItemIds.POLISHED_CINNABAR_STAIRS,
				BlockItemIds.CINNABAR_BRICK_STAIRS,
				BlockItemIds.SULFUR_STAIRS,
				BlockItemIds.POLISHED_SULFUR_STAIRS,
				BlockItemIds.SULFUR_BRICK_STAIRS
			)
			.addAll(BlockItemIds.CUT_COPPER_STAIRS.asList());
		this.tag(BlockItemTags.ANVIL).add(BlockItemIds.ANVIL, BlockItemIds.CHIPPED_ANVIL, BlockItemIds.DAMAGED_ANVIL);
		this.tag(BlockItemTags.RAILS).add(BlockItemIds.RAIL, BlockItemIds.POWERED_RAIL, BlockItemIds.DETECTOR_RAIL, BlockItemIds.ACTIVATOR_RAIL);
		this.tag(BlockItemTags.LEAVES)
			.add(
				BlockItemIds.JUNGLE_LEAVES,
				BlockItemIds.OAK_LEAVES,
				BlockItemIds.SPRUCE_LEAVES,
				BlockItemIds.PALE_OAK_LEAVES,
				BlockItemIds.DARK_OAK_LEAVES,
				BlockItemIds.ACACIA_LEAVES,
				BlockItemIds.BIRCH_LEAVES,
				BlockItemIds.AZALEA_LEAVES,
				BlockItemIds.FLOWERING_AZALEA_LEAVES,
				BlockItemIds.MANGROVE_LEAVES,
				BlockItemIds.CHERRY_LEAVES
			);
		this.tag(BlockItemTags.WOODEN_TRAPDOORS)
			.add(
				BlockItemIds.ACACIA_TRAPDOOR,
				BlockItemIds.BIRCH_TRAPDOOR,
				BlockItemIds.DARK_OAK_TRAPDOOR,
				BlockItemIds.PALE_OAK_TRAPDOOR,
				BlockItemIds.JUNGLE_TRAPDOOR,
				BlockItemIds.OAK_TRAPDOOR,
				BlockItemIds.SPRUCE_TRAPDOOR,
				BlockItemIds.CRIMSON_TRAPDOOR,
				BlockItemIds.WARPED_TRAPDOOR,
				BlockItemIds.MANGROVE_TRAPDOOR,
				BlockItemIds.BAMBOO_TRAPDOOR,
				BlockItemIds.CHERRY_TRAPDOOR
			);
		this.tag(BlockItemTags.TRAPDOORS).addTag(BlockItemTags.WOODEN_TRAPDOORS).add(BlockItemIds.IRON_TRAPDOOR).addAll(BlockItemIds.COPPER_TRAPDOOR.asList());
		this.tag(BlockItemTags.SMALL_FLOWERS).add(smallFlowersInteractingWithBees).add(BlockItemIds.CLOSED_EYEBLOSSOM, BlockItemIds.GOLDEN_DANDELION);
		this.tag(BlockItemTags.FLOWERS).addTag(BlockItemTags.SMALL_FLOWERS).add(otherFlowers);
		this.tag(BlockItemTags.BEDS).addAll(BlockItemIds.BED.asList());
		this.tag(BlockItemTags.FENCES).addTag(BlockItemTags.WOODEN_FENCES).add(BlockItemIds.NETHER_BRICK_FENCE);
		this.tag(BlockItemTags.SOUL_FIRE_BASE_BLOCKS).add(BlockItemIds.SOUL_SAND, BlockItemIds.SOUL_SOIL);
		this.tag(BlockItemTags.CANDLES).add(BlockItemIds.CANDLE).addAll(BlockItemIds.DYED_CANDLE.asList());
		this.tag(BlockItemTags.DAMPENS_VIBRATIONS).addTag(BlockItemTags.WOOL).addTag(BlockItemTags.WOOL_CARPETS);
		this.tag(BlockItemTags.GOLD_ORES).add(BlockItemIds.GOLD_ORE, BlockItemIds.NETHER_GOLD_ORE, BlockItemIds.DEEPSLATE_GOLD_ORE);
		this.tag(BlockItemTags.IRON_ORES).add(BlockItemIds.IRON_ORE, BlockItemIds.DEEPSLATE_IRON_ORE);
		this.tag(BlockItemTags.DIAMOND_ORES).add(BlockItemIds.DIAMOND_ORE, BlockItemIds.DEEPSLATE_DIAMOND_ORE);
		this.tag(BlockItemTags.REDSTONE_ORES).add(BlockItemIds.REDSTONE_ORE, BlockItemIds.DEEPSLATE_REDSTONE_ORE);
		this.tag(BlockItemTags.LAPIS_ORES).add(BlockItemIds.LAPIS_ORE, BlockItemIds.DEEPSLATE_LAPIS_ORE);
		this.tag(BlockItemTags.COAL_ORES).add(BlockItemIds.COAL_ORE, BlockItemIds.DEEPSLATE_COAL_ORE);
		this.tag(BlockItemTags.EMERALD_ORES).add(BlockItemIds.EMERALD_ORE, BlockItemIds.DEEPSLATE_EMERALD_ORE);
		this.tag(BlockItemTags.COPPER_ORES).add(BlockItemIds.COPPER_ORE, BlockItemIds.DEEPSLATE_COPPER_ORE);
		this.tag(BlockItemTags.DIRT).add(BlockItemIds.DIRT, BlockItemIds.COARSE_DIRT, BlockItemIds.ROOTED_DIRT);
		this.tag(BlockItemTags.MUD).add(BlockItemIds.MUD, BlockItemIds.MUDDY_MANGROVE_ROOTS);
		this.tag(BlockItemTags.MOSS_BLOCKS).add(BlockItemIds.MOSS_BLOCK, BlockItemIds.PALE_MOSS_BLOCK);
		this.tag(BlockItemTags.GRASS_BLOCKS).add(BlockItemIds.GRASS_BLOCK, BlockItemIds.PODZOL, BlockItemIds.MYCELIUM);
		this.tag(BlockItemTags.TERRACOTTA).add(BlockItemIds.TERRACOTTA).addAll(BlockItemIds.DYED_TERRACOTTA.asList());
		this.tag(BlockItemTags.GLAZED_TERRACOTTA).addAll(BlockItemIds.GLAZED_TERRACOTTA.asList());
		this.tag(BlockItemTags.CONCRETE).addAll(BlockItemIds.CONCRETE.asList());
		this.tag(BlockItemTags.CONCRETE_POWDERS).addAll(BlockItemIds.CONCRETE_POWDER.asList());
		this.tag(BlockItemTags.COMPLETES_FIND_TREE_TUTORIAL).addTag(BlockItemTags.LOGS).addTag(BlockItemTags.LEAVES).addTag(BlockItemTags.WART_BLOCKS);
		this.tag(BlockItemTags.SHULKER_BOXES).add(BlockItemIds.SHULKER_BOX).addAll(BlockItemIds.DYED_SHULKER_BOX.asList());
		this.tag(BlockItemTags.COPPER_CHESTS).addAll(BlockItemIds.COPPER_CHEST.asList());
		this.tag(BlockItemTags.LIGHTNING_RODS).addAll(BlockItemIds.LIGHTNING_ROD.asList());
		this.tag(BlockItemTags.COPPER_GOLEM_STATUES).addAll(BlockItemIds.COPPER_GOLEM_STATUE.asList());
		this.tag(BlockItemTags.COPPER).addAll(BlockItemIds.COPPER_BLOCK.asList());
		this.tag(BlockItemTags.CHAINS).add(BlockItemIds.IRON_CHAIN).addAll(BlockItemIds.COPPER_CHAIN.asList());
		this.tag(BlockItemTags.WOODEN_SHELVES)
			.add(
				BlockItemIds.ACACIA_SHELF,
				BlockItemIds.BAMBOO_SHELF,
				BlockItemIds.BIRCH_SHELF,
				BlockItemIds.CHERRY_SHELF,
				BlockItemIds.CRIMSON_SHELF,
				BlockItemIds.DARK_OAK_SHELF,
				BlockItemIds.JUNGLE_SHELF,
				BlockItemIds.MANGROVE_SHELF,
				BlockItemIds.OAK_SHELF,
				BlockItemIds.PALE_OAK_SHELF,
				BlockItemIds.SPRUCE_SHELF,
				BlockItemIds.WARPED_SHELF
			);
		this.tag(BlockItemTags.LANTERNS).add(BlockItemIds.LANTERN, BlockItemIds.SOUL_LANTERN).addAll(BlockItemIds.COPPER_LANTERN.asList());
		this.tag(BlockItemTags.BARS).add(BlockItemIds.IRON_BARS).addAll(BlockItemIds.COPPER_BARS.asList());
		this.tag(BlockItemTags.SIGNS)
			.add(
				BlockItemIds.OAK_SIGN,
				BlockItemIds.SPRUCE_SIGN,
				BlockItemIds.BIRCH_SIGN,
				BlockItemIds.ACACIA_SIGN,
				BlockItemIds.JUNGLE_SIGN,
				BlockItemIds.DARK_OAK_SIGN,
				BlockItemIds.PALE_OAK_SIGN,
				BlockItemIds.CRIMSON_SIGN,
				BlockItemIds.WARPED_SIGN,
				BlockItemIds.MANGROVE_SIGN,
				BlockItemIds.BAMBOO_SIGN,
				BlockItemIds.CHERRY_SIGN
			);
		this.tag(BlockItemTags.HANGING_SIGNS)
			.add(
				BlockItemIds.OAK_HANGING_SIGN,
				BlockItemIds.SPRUCE_HANGING_SIGN,
				BlockItemIds.BIRCH_HANGING_SIGN,
				BlockItemIds.ACACIA_HANGING_SIGN,
				BlockItemIds.CHERRY_HANGING_SIGN,
				BlockItemIds.JUNGLE_HANGING_SIGN,
				BlockItemIds.DARK_OAK_HANGING_SIGN,
				BlockItemIds.PALE_OAK_HANGING_SIGN,
				BlockItemIds.CRIMSON_HANGING_SIGN,
				BlockItemIds.WARPED_HANGING_SIGN,
				BlockItemIds.MANGROVE_HANGING_SIGN,
				BlockItemIds.BAMBOO_HANGING_SIGN
			);
		this.tag(BlockItemTags.BEE_FOOD).add(smallFlowersInteractingWithBees).add(otherFlowers);
	}
}
