package net.minecraft.data.loot.packs;

import java.util.function.BiConsumer;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.loot.LootTableSubProvider;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.SetStewEffectFunction;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

public record VanillaArchaeologyLoot(HolderLookup.Provider registries) implements LootTableSubProvider {
	@Override
	public void generate(final BiConsumer<ResourceKey<LootTable>, LootTable.Builder> output) {
		output.accept(
			BuiltInLootTables.DESERT_WELL_ARCHAEOLOGY,
			LootTable.lootTable()
				.withPool(
					LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0F))
						.add(LootItem.lootTableItem(Items.ARMS_UP_POTTERY_SHERD).setWeight(2))
						.add(LootItem.lootTableItem(Items.BREWER_POTTERY_SHERD).setWeight(2))
						.add(LootItem.lootTableItem(Items.BRICK))
						.add(LootItem.lootTableItem(Items.EMERALD))
						.add(LootItem.lootTableItem(Items.STICK))
						.add(
							LootItem.lootTableItem(Items.SUSPICIOUS_STEW)
								.apply(
									SetStewEffectFunction.stewEffect()
										.withEffect(MobEffects.NIGHT_VISION, UniformGenerator.between(7.0F, 10.0F))
										.withEffect(MobEffects.JUMP_BOOST, UniformGenerator.between(7.0F, 10.0F))
										.withEffect(MobEffects.WEAKNESS, UniformGenerator.between(6.0F, 8.0F))
										.withEffect(MobEffects.BLINDNESS, UniformGenerator.between(5.0F, 7.0F))
										.withEffect(MobEffects.POISON, UniformGenerator.between(10.0F, 20.0F))
										.withEffect(MobEffects.SATURATION, UniformGenerator.between(7.0F, 10.0F))
								)
						)
				)
		);
		output.accept(
			BuiltInLootTables.DESERT_PYRAMID_ARCHAEOLOGY,
			LootTable.lootTable()
				.withPool(
					LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0F))
						.add(LootItem.lootTableItem(Items.ARCHER_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.MINER_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.PRIZE_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.SKULL_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.DIAMOND))
						.add(LootItem.lootTableItem(Items.TNT))
						.add(LootItem.lootTableItem(Items.GUNPOWDER))
						.add(LootItem.lootTableItem(Items.EMERALD))
				)
		);
		output.accept(
			BuiltInLootTables.TRAIL_RUINS_ARCHAEOLOGY_COMMON,
			LootTable.lootTable()
				.withPool(
					LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0F))
						.add(LootItem.lootTableItem(Items.EMERALD).setWeight(2))
						.add(LootItem.lootTableItem(Items.WHEAT).setWeight(2))
						.add(LootItem.lootTableItem(Items.WOODEN_HOE).setWeight(2))
						.add(LootItem.lootTableItem(Items.CLAY).setWeight(2))
						.add(LootItem.lootTableItem(Items.BRICK).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYE.yellow()).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYE.blue()).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYE.lightBlue()).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYE.white()).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYE.orange()).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYED_CANDLE.red()).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYED_CANDLE.green()).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYED_CANDLE.purple()).setWeight(2))
						.add(LootItem.lootTableItem(Items.DYED_CANDLE.brown()).setWeight(2))
						.add(LootItem.lootTableItem(Items.STAINED_GLASS_PANE.magenta()))
						.add(LootItem.lootTableItem(Items.STAINED_GLASS_PANE.pink()))
						.add(LootItem.lootTableItem(Items.STAINED_GLASS_PANE.blue()))
						.add(LootItem.lootTableItem(Items.STAINED_GLASS_PANE.lightBlue()))
						.add(LootItem.lootTableItem(Items.STAINED_GLASS_PANE.red()))
						.add(LootItem.lootTableItem(Items.STAINED_GLASS_PANE.yellow()))
						.add(LootItem.lootTableItem(Items.STAINED_GLASS_PANE.purple()))
						.add(LootItem.lootTableItem(Items.SPRUCE_HANGING_SIGN))
						.add(LootItem.lootTableItem(Items.OAK_HANGING_SIGN))
						.add(LootItem.lootTableItem(Items.GOLD_NUGGET))
						.add(LootItem.lootTableItem(Items.COAL))
						.add(LootItem.lootTableItem(Items.WHEAT_SEEDS))
						.add(LootItem.lootTableItem(Items.BEETROOT_SEEDS))
						.add(LootItem.lootTableItem(Items.DEAD_BUSH))
						.add(LootItem.lootTableItem(Items.FLOWER_POT))
						.add(LootItem.lootTableItem(Items.STRING))
						.add(LootItem.lootTableItem(Items.LEAD))
				)
		);
		output.accept(
			BuiltInLootTables.TRAIL_RUINS_ARCHAEOLOGY_RARE,
			LootTable.lootTable()
				.withPool(
					LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0F))
						.add(LootItem.lootTableItem(Items.BURN_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.DANGER_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.FRIEND_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.HEART_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.HEARTBREAK_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.HOWL_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.SHEAF_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.WAYFINDER_ARMOR_TRIM_SMITHING_TEMPLATE))
						.add(LootItem.lootTableItem(Items.RAISER_ARMOR_TRIM_SMITHING_TEMPLATE))
						.add(LootItem.lootTableItem(Items.SHAPER_ARMOR_TRIM_SMITHING_TEMPLATE))
						.add(LootItem.lootTableItem(Items.HOST_ARMOR_TRIM_SMITHING_TEMPLATE))
						.add(LootItem.lootTableItem(Items.MUSIC_DISC_RELIC))
				)
		);
		output.accept(
			BuiltInLootTables.OCEAN_RUIN_WARM_ARCHAEOLOGY,
			LootTable.lootTable()
				.withPool(
					LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0F))
						.add(LootItem.lootTableItem(Items.ANGLER_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.SHELTER_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.SNORT_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.SNIFFER_EGG))
						.add(LootItem.lootTableItem(Items.IRON_AXE))
						.add(LootItem.lootTableItem(Items.EMERALD).setWeight(2))
						.add(LootItem.lootTableItem(Items.WHEAT).setWeight(2))
						.add(LootItem.lootTableItem(Items.WOODEN_HOE).setWeight(2))
						.add(LootItem.lootTableItem(Items.COAL).setWeight(2))
						.add(LootItem.lootTableItem(Items.GOLD_NUGGET).setWeight(2))
				)
		);
		output.accept(
			BuiltInLootTables.OCEAN_RUIN_COLD_ARCHAEOLOGY,
			LootTable.lootTable()
				.withPool(
					LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0F))
						.add(LootItem.lootTableItem(Items.BLADE_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.EXPLORER_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.MOURNER_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.PLENTY_POTTERY_SHERD))
						.add(LootItem.lootTableItem(Items.IRON_AXE))
						.add(LootItem.lootTableItem(Items.EMERALD).setWeight(2))
						.add(LootItem.lootTableItem(Items.WHEAT).setWeight(2))
						.add(LootItem.lootTableItem(Items.WOODEN_HOE).setWeight(2))
						.add(LootItem.lootTableItem(Items.COAL).setWeight(2))
						.add(LootItem.lootTableItem(Items.GOLD_NUGGET).setWeight(2))
				)
		);
	}
}
